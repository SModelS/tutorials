# Re-Interpretation Workshop 2021


<img src="https://smodels.github.io/pics/banner.png" alt="banner">

SModelS notebook for the [Re-Interpretation](https://indico.cern.ch/event/982553/) virtual conference.

[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/SModelS/tutorials/rif2021?filepath=index.ipynb)


